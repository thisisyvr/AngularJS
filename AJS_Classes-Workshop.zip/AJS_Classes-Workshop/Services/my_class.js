function class_one(arg1) {
    this.fun_one = function () {
        return arg1;
    };
};