﻿app.controller("calc", calc);
function calc($scope) {
    $scope.calc = "Calculations Soon....!";
}